package com.noormuslim.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.webkit.WebSettings;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handle(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handle(url);
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    private boolean handle(String url) {
        if (url.startsWith("file:///android_asset/books/")) {
            String name = Uri.parse(url).getLastPathSegment();
            try {
                File cache = new File(getCacheDir(), name);
                InputStream in = getAssets().open("books/" + name);
                FileOutputStream out = new FileOutputStream(cache);
                byte[] b = new byte[8192]; int n;
                while((n=in.read(b))>0) out.write(b,0,n);
                in.close(); out.close();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(cache), "application/pdf");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch(Exception e) {
                Toast.makeText(this, "لم أجد الملف. أضف PDF إلى assets/books", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            return true;
        }
        return false;
    }
    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
