مشروع نور المسلم Android WebView (ملفات مشروع Android Studio)
مهم: هذا مشروع مصدر وليس APK جاهزاً، ويتطلب Android Studio لبناء APK.

إضافة الكتب:
انسخ PDF إلى:
app/src/main/assets/books/
وغيّر الأسماء:
book1.pdf = عمدة القاري شرح صحيح البخاري - الجزء الأول
book2.pdf = كتاب الحج والعمرة من صحيح أبي عبدالله البخاري
book3.pdf = صحيح مسلم - الجزء الثاني
book4.pdf = صحيح مسلم - الجزء الأول

بناء APK:
1. افتح Android Studio على الكمبيوتر.
2. اختر Open وافتح مجلد NoorMuslim.
3. انتظر Gradle Sync.
4. Build > Build APK(s).
5. انسخ APK من app/build/outputs/apk/debug إلى هاتفك.

ملاحظة: Android Studio يحتاج كمبيوتر، ولا يتولد APK مباشرة من ZIP على الهاتف. PDF يفتح بواسطة قارئ PDF خارجي على Android.
